import numpy as np
import matplotlib.pyplot as plt

#Create a numpy array with the population data

path=r"C:\Users\malay\Downloads\US_population.txt"
f = open(path,'r')
pop_data = np.array([x.split(',') for x in f.read().split('\n')[1:]])
#Calculate the annual growth rate of the population based on the method you used in Q2(2)
annual_growth = pop_data[2::2,1].astype('int')-pop_data[1::2,1].astype('int')
growth_rates = np.divide(annual_growth,pop_data[1::2,1].astype('int'))
years = np.array([int(x.split('-')[0]) for x in pop_data[:,0]])
years_alt = years[1::2]
#Plot the population and annual growth rate as **PT5_1.jpg** and **PT5_2.jpg**.
plt.figure(1)
plt.plot(years[years<=2020],pop_data[:,1].astype('int')[years <= 2020])
plt.plot(years[years>2020],pop_data[:,1].astype('int')[years>2020],linestyle = '--',color = 'b')
plt.title('US Population')
plt.figure(2)
plt.plot(years_alt[years_alt <= 2020],growth_rates[years_alt <= 2020])
plt.plot(years_alt[years_alt>2020],growth_rates[years_alt > 2020],linestyle = '--',color = 'b')
plt.title('Population growth rates')


